# Dailyn Cid Sepulveda
# soy nueva
# 17-03-2025

mi_lista = ["brasil", "ecuador", "peru","colombia", "chile"]

print(mi_lista[2])
mi_lista[-1]= "jamaica"
print(mi_lista)
mi_lista.reverse()
print(mi_lista)
print(mi_lista[1:3])
print(mi_lista[2:])
print(mi_lista[:4])

mi_lista[-1]= 0
print(mi_lista)
mi_lista.reverse()
print(mi_lista)